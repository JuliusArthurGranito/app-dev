﻿namespace Reina_Beauty_and_Wellness_Website
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.SidebarButton = new System.Windows.Forms.PictureBox();
            this.Sidebar = new System.Windows.Forms.FlowLayoutPanel();
            this.Home = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.Products = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Chatbot = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Cart = new System.Windows.Forms.Button();
            this.ProductContainer = new System.Windows.Forms.FlowLayoutPanel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button5 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button8 = new System.Windows.Forms.Button();
            this.ProductTransition = new System.Windows.Forms.Timer(this.components);
            this.SidebarTransition = new System.Windows.Forms.Timer(this.components);
            this.panelContainer = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SidebarButton)).BeginInit();
            this.Sidebar.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.ProductContainer.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(152)))), ((int)(((byte)(204)))), ((int)(((byte)(98)))));
            this.panel1.Controls.Add(this.SidebarButton);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1032, 74);
            this.panel1.TabIndex = 0;
            // 
            // SidebarButton
            // 
            this.SidebarButton.Image = ((System.Drawing.Image)(resources.GetObject("SidebarButton.Image")));
            this.SidebarButton.Location = new System.Drawing.Point(24, 22);
            this.SidebarButton.Margin = new System.Windows.Forms.Padding(4);
            this.SidebarButton.Name = "SidebarButton";
            this.SidebarButton.Size = new System.Drawing.Size(35, 31);
            this.SidebarButton.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.SidebarButton.TabIndex = 2;
            this.SidebarButton.TabStop = false;
            this.SidebarButton.Click += new System.EventHandler(this.SidebarButton_Click);
            // 
            // Sidebar
            // 
            this.Sidebar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.Sidebar.Controls.Add(this.panel2);
            this.Sidebar.Controls.Add(this.ProductContainer);
            this.Sidebar.Controls.Add(this.panel5);
            this.Sidebar.Controls.Add(this.panel4);
            this.Sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.Sidebar.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.Sidebar.Location = new System.Drawing.Point(0, 74);
            this.Sidebar.Name = "Sidebar";
            this.Sidebar.Size = new System.Drawing.Size(307, 598);
            this.Sidebar.TabIndex = 1;
            this.Sidebar.Paint += new System.Windows.Forms.PaintEventHandler(this.Sidebar_Paint);
            // 
            // Home
            // 
            this.Home.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.Home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Home.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Home.ForeColor = System.Drawing.Color.Black;
            this.Home.Image = ((System.Drawing.Image)(resources.GetObject("Home.Image")));
            this.Home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Home.Location = new System.Drawing.Point(-1, -1);
            this.Home.Name = "Home";
            this.Home.Size = new System.Drawing.Size(230, 62);
            this.Home.TabIndex = 3;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = false;
            this.Home.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.Home);
            this.panel2.Location = new System.Drawing.Point(3, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(213, 56);
            this.panel2.TabIndex = 3;
            // 
            // Products
            // 
            this.Products.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.Products.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Products.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Products.ForeColor = System.Drawing.Color.Black;
            this.Products.Image = ((System.Drawing.Image)(resources.GetObject("Products.Image")));
            this.Products.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Products.Location = new System.Drawing.Point(-1, -1);
            this.Products.Name = "Products";
            this.Products.Size = new System.Drawing.Size(230, 62);
            this.Products.TabIndex = 3;
            this.Products.Text = "Products";
            this.Products.UseVisualStyleBackColor = false;
            this.Products.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.Products);
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(213, 56);
            this.panel3.TabIndex = 4;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.Chatbot);
            this.panel4.Location = new System.Drawing.Point(3, 183);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(213, 56);
            this.panel4.TabIndex = 5;
            // 
            // Chatbot
            // 
            this.Chatbot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.Chatbot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Chatbot.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Chatbot.ForeColor = System.Drawing.Color.Black;
            this.Chatbot.Image = ((System.Drawing.Image)(resources.GetObject("Chatbot.Image")));
            this.Chatbot.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Chatbot.Location = new System.Drawing.Point(-1, -1);
            this.Chatbot.Name = "Chatbot";
            this.Chatbot.Size = new System.Drawing.Size(230, 62);
            this.Chatbot.TabIndex = 3;
            this.Chatbot.Text = "Chatbot";
            this.Chatbot.UseVisualStyleBackColor = false;
            this.Chatbot.Click += new System.EventHandler(this.Chatbot_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.Cart);
            this.panel5.Location = new System.Drawing.Point(3, 121);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(213, 56);
            this.panel5.TabIndex = 6;
            // 
            // Cart
            // 
            this.Cart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.Cart.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Cart.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Cart.ForeColor = System.Drawing.Color.Black;
            this.Cart.Image = ((System.Drawing.Image)(resources.GetObject("Cart.Image")));
            this.Cart.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Cart.Location = new System.Drawing.Point(-1, -1);
            this.Cart.Name = "Cart";
            this.Cart.Size = new System.Drawing.Size(230, 62);
            this.Cart.TabIndex = 3;
            this.Cart.Text = "Cart";
            this.Cart.UseVisualStyleBackColor = false;
            this.Cart.Click += new System.EventHandler(this.Cart_Click);
            // 
            // ProductContainer
            // 
            this.ProductContainer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.ProductContainer.Controls.Add(this.panel3);
            this.ProductContainer.Controls.Add(this.panel6);
            this.ProductContainer.Controls.Add(this.panel7);
            this.ProductContainer.Controls.Add(this.panel8);
            this.ProductContainer.Controls.Add(this.panel9);
            this.ProductContainer.Location = new System.Drawing.Point(0, 62);
            this.ProductContainer.Margin = new System.Windows.Forms.Padding(0);
            this.ProductContainer.Name = "ProductContainer";
            this.ProductContainer.Size = new System.Drawing.Size(211, 56);
            this.ProductContainer.TabIndex = 7;
            this.ProductContainer.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel2_Paint);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button5);
            this.panel6.Location = new System.Drawing.Point(3, 59);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(213, 56);
            this.panel6.TabIndex = 8;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.Color.Black;
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button5.Location = new System.Drawing.Point(-2, -3);
            this.button5.Margin = new System.Windows.Forms.Padding(0);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(230, 62);
            this.button5.TabIndex = 3;
            this.button5.Text = "SkinCare";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button6);
            this.panel7.Location = new System.Drawing.Point(3, 121);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(213, 56);
            this.panel7.TabIndex = 6;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.Color.Black;
            this.button6.Image = ((System.Drawing.Image)(resources.GetObject("button6.Image")));
            this.button6.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button6.Location = new System.Drawing.Point(-2, -3);
            this.button6.Margin = new System.Windows.Forms.Padding(0);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(230, 62);
            this.button6.TabIndex = 3;
            this.button6.Text = "Cosmetics";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.button7);
            this.panel8.Location = new System.Drawing.Point(3, 183);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(213, 56);
            this.panel8.TabIndex = 8;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.Color.Black;
            this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
            this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button7.Location = new System.Drawing.Point(-2, -3);
            this.button7.Margin = new System.Windows.Forms.Padding(0);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(230, 62);
            this.button7.TabIndex = 3;
            this.button7.Text = "Consumables";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.button8);
            this.panel9.Location = new System.Drawing.Point(3, 245);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(213, 56);
            this.panel9.TabIndex = 8;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(202)))), ((int)(((byte)(179)))));
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.ForeColor = System.Drawing.Color.Black;
            this.button8.Image = ((System.Drawing.Image)(resources.GetObject("button8.Image")));
            this.button8.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button8.Location = new System.Drawing.Point(-2, -3);
            this.button8.Margin = new System.Windows.Forms.Padding(0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(230, 62);
            this.button8.TabIndex = 3;
            this.button8.Text = "Aromatherapy";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // ProductTransition
            // 
            this.ProductTransition.Interval = 1;
            this.ProductTransition.Tick += new System.EventHandler(this.ProductTransition_Tick);
            // 
            // SidebarTransition
            // 
            this.SidebarTransition.Interval = 1;
            this.SidebarTransition.Tick += new System.EventHandler(this.SidebarTransition_Tick);
            // 
            // panelContainer
            // 
            this.panelContainer.Location = new System.Drawing.Point(58, 74);
            this.panelContainer.Name = "panelContainer";
            this.panelContainer.Size = new System.Drawing.Size(971, 598);
            this.panelContainer.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(234)))), ((int)(((byte)(220)))), ((int)(((byte)(204)))));
            this.ClientSize = new System.Drawing.Size(1032, 672);
            this.Controls.Add(this.Sidebar);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelContainer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.IsMdiContainer = true;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.SidebarButton)).EndInit();
            this.Sidebar.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.ProductContainer.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox SidebarButton;
        private System.Windows.Forms.FlowLayoutPanel Sidebar;
        private System.Windows.Forms.Button Home;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button Products;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button Chatbot;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button Cart;
        private System.Windows.Forms.FlowLayoutPanel ProductContainer;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Timer ProductTransition;
        private System.Windows.Forms.Timer SidebarTransition;
        private System.Windows.Forms.Panel panelContainer;
    }
}

