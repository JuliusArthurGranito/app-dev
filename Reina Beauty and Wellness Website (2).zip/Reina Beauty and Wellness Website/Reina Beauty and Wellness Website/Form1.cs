﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Reina_Beauty_and_Wellness_Website
{

    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            formHome Home = new formHome();

           
            Home.TopLevel = false;
            Home.FormBorderStyle = FormBorderStyle.None;
            Home.Dock = DockStyle.Fill;

            panelContainer.Controls.Clear();

            panelContainer.Controls.Add(Home);

            
            Home.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ProductTransition.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }
        bool productExpand = false;
        private void ProductTransition_Tick(object sender, EventArgs e)
        {
            if (productExpand == false)
            {
                ProductContainer.Height +=10;
                if (ProductContainer.Height >= 295)
                {
                    ProductTransition.Stop();
                    productExpand = true;
                }
            }
            else 
            {
                ProductContainer.Height -=10;
                if (ProductContainer.Height <=56) 
                {
                    ProductTransition.Stop();
                    productExpand = false;
                }
            }
        }
        bool sidebarExpand = true;
        private void SidebarTransition_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                Sidebar.Width -=10;
                if (Sidebar.Width <=50)
                {
                    sidebarExpand = false;
                    SidebarTransition.Stop();

                    
                }
            }
            else 
            {
                Sidebar.Width +=10;
                if (Sidebar.Width >=199) 
                {
                    sidebarExpand=true;
                    SidebarTransition.Stop();

                    
                }
            }
        }

        private void SidebarButton_Click(object sender, EventArgs e)
        {
            SidebarTransition.Start();
        }

        private void Sidebar_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            formSkinCare Skincare = new formSkinCare();


            Skincare.TopLevel = false;
            Skincare.FormBorderStyle = FormBorderStyle.None;
            Skincare.Dock = DockStyle.Fill;

            panelContainer.Controls.Clear();

            panelContainer.Controls.Add(Skincare);


            Skincare.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            formCosmetics Cosmetics = new formCosmetics();

            Cosmetics.TopLevel = false;
            Cosmetics.FormBorderStyle = FormBorderStyle.None;
            Cosmetics.Dock = DockStyle.Fill;

            panelContainer.Controls.Clear();

            panelContainer.Controls.Add(Cosmetics);

            Cosmetics.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            formConsumable Consumable = new formConsumable();

            Consumable.TopLevel = false;
            Consumable.FormBorderStyle = FormBorderStyle.None;
            Consumable.Dock = DockStyle.Fill;

            panelContainer.Controls.Clear();

            panelContainer.Controls.Add(Consumable);

            Consumable.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            formAromatherapy Aroma = new formAromatherapy();

            Aroma.TopLevel = false;
            Aroma.FormBorderStyle = FormBorderStyle.None;
            Aroma.Dock = DockStyle.Fill;

            panelContainer.Controls.Clear();

            panelContainer.Controls.Add(Aroma);

            Aroma.Show();
        }

        private void Cart_Click(object sender, EventArgs e)
        {
            formCart Cart = new formCart();

            Cart.TopLevel = false;
            Cart.FormBorderStyle = FormBorderStyle.None;
            Cart.Dock = DockStyle.Fill;

            panelContainer.Controls.Clear();

            panelContainer.Controls.Add(Cart);

            Cart.Show();
        }

        private void Chatbot_Click(object sender, EventArgs e)
        {
            formChatbot Chatbot = new formChatbot();

            Chatbot.TopLevel = false;
            Chatbot.FormBorderStyle = FormBorderStyle.None;
            Chatbot.Dock = DockStyle.Fill;

            panelContainer.Controls.Clear();

            panelContainer.Controls.Add(Chatbot);

            Chatbot.Show();
        }
    }
}
